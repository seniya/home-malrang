<template>
  <div>
    <p>메인 화면</p>
  </div>
</template>

<script lang="ts">
export default {
  name: 'homeMain',
  inheritAttrs: false,
  customOptions: {}
}
</script>
