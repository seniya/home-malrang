<template>
  <div>
    <p>페이지 3화면</p>
  </div>
</template>

<script lang="ts">
export default {
  name: 'pageSam',
  inheritAttrs: false,
  customOptions: {}
}
</script>
