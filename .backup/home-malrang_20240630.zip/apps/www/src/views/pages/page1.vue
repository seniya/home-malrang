<template>
  <div>
    <p>페이지 1화면</p>
  </div>
  <div>
  </div>
</template>

<script setup lang="ts">

</script>

<script lang="ts">
export default {
  name: 'pageOne',
  inheritAttrs: false,
  customOptions: {}
}
</script>
