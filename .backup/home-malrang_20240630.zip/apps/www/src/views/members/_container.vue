<template>
  <router-view></router-view>
</template>

<script lang="ts">
export default {
  name: 'membersContainer',
  inheritAttrs: false,
  customOptions: {}
}
</script>
